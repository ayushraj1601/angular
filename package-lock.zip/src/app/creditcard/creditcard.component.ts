import { Component, OnInit } from '@angular/core';
import { CreditCard } from '../model/creditcard';
import { CreditCardService } from '../service/creditcard.service';

@Component({
  selector: 'app-creditcard',
  templateUrl: './creditcard.component.html',
  styleUrls: ['./creditcard.component.css']
})
export class CreditcardComponent implements OnInit {

  newCard: CreditCard;
  cards: CreditCard[];

  constructor(private cardService: CreditCardService) {
    this.cards = [];
    this.newCard = new CreditCard();
  }

  ngOnInit() {
    this.load();
  }

  load() {
    this.cardService.viewall().subscribe(
      (data) => { 
        this.cards = data;
      }
    );
  }

  addCard() {
    this.cardService.addcard(this.newCard
    ).subscribe(
      (data) => {
        this.newCard  = new CreditCard();
        this.load();
      }
    );

  }
  deleteCard(cardNumber: number) {
    this.cardService.deletecard(cardNumber).subscribe(
      () => {
        this.load();
      }
    );
  }

}
