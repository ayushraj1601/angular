import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-credit-requests',
  templateUrl: './credit-requests.component.html',
  styleUrls: ['./credit-requests.component.css']
})
export class CreditRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
