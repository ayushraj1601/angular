import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from 'src/environments/environment.prod';
import { Observable } from 'rxjs';
import { CreditCard } from '../model/creditcard';

@Injectable({
    providedIn: 'root'
})

export class CreditCardService {

    baseUrl: string;

    constructor(private http: HttpClient) {
        this.baseUrl = `${environment.baseMwUrl}/creditCard`;
    }

    viewall(): Observable<CreditCard[]> {
        return this.http.get<CreditCard[]>(this.baseUrl);
    }
    addcard(card: CreditCard): Observable<CreditCard> {
        return this.http.post<CreditCard>(this.baseUrl, card);
    }
    deletecard(cardNumber: number): Observable<any> {
        return this.http.delete<any>(`${this.baseUrl}/${cardNumber}`);
    }



}