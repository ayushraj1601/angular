import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-autopayment',
  templateUrl: './autopayment.component.html',
  styleUrls: ['./autopayment.component.css']
})
export class AutopaymentComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
