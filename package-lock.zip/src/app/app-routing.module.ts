import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import {DashboardComponent} from './dashboard/dashboard.component';


import { from } from 'rxjs';
import { CreditcardComponent } from './creditcard/creditcard.component';
import { AutopaymentComponent } from './autopayment/autopayment.component';

const routes: Routes = [
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'',component:DashboardComponent,pathMatch:'full'},
  {path:'creditcard',component:CreditcardComponent},
  {path:'autopayment',component:AutopaymentComponent}
 
  
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
