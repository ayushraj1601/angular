import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RmHistoryComponent } from './rm-history.component';

describe('RmHistoryComponent', () => {
  let component: RmHistoryComponent;
  let fixture: ComponentFixture<RmHistoryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RmHistoryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RmHistoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
